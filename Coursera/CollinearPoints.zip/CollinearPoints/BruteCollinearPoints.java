
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Arrays;

public class BruteCollinearPoints {

    private final LineSegment[] segments;

    // finds all line segments containing 4 points
    public BruteCollinearPoints(Point[] points) {
        // Corner case
        if (points == null) throw new IllegalArgumentException();
        for (int i = 0; i < points.length; i++) {
            for (int j = 0; j < points.length; j++) {
                if (points[i] == null || points[j] == null) throw new IllegalArgumentException();
                if (i != j && points[i].compareTo(points[j]) == 0) throw new IllegalArgumentException();
            }
        }

        int n = points.length;
        Point[] p = Arrays.copyOf(points, n);
        ArrayList<LineSegment> segList = new ArrayList<>();
        Arrays.sort(p);
        for (int i = 0; i < n - 3; i++) {
            for (int j = 0; j < n - 2; j++) {
                for (int k = 0; k < n - 1; k++) {
                    for (int l = 0; l < n; l++) {
                        if (p[i].slopeTo(p[j]) == p[i].slopeTo(p[k]) && p[i].slopeTo(p[j]) == p[i].slopeTo(p[l])) {
                            segList.add(new LineSegment(p[i], p[l]));
                        }
                    }
                }
            }
        }
        segments = new LineSegment[segList.size()];
        segList.toArray(segments);
    }

    // the number of line segments
    public int numberOfSegments() {
        return segments.length;
    }

    public LineSegment[] segments() {
        return segments;
    }
    public static void main(String[] args) {

        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        BruteCollinearPoints collinear = new BruteCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }
}
